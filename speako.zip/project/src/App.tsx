import { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import PopularTutors from '@/components/PopularTutors';
import Features from '@/components/Features';
import HowItWorks from '@/components/HowItWorks';
import Testimonials from '@/components/Testimonials';
import Faq from '@/components/Faq';
import CtaBanner from '@/components/CtaBanner';
import Footer from '@/components/Footer';
import BuyPointsModal from '@/components/BuyPointsModal';
import TutorPayout from '@/components/TutorPayout';
import VideoCall from '@/components/VideoCall';
import TutorApply from '@/components/TutorApply';
import AdminLayout, { type AdminPage } from '@/components/admin/AdminLayout';
import AdminGate from '@/components/AdminGate';
import AdminDashboard from '@/components/admin/AdminDashboard';
import AdminTutors from '@/components/admin/AdminTutors';
import AdminStudents from '@/components/admin/AdminStudents';
import AdminPayments from '@/components/admin/AdminPayments';
import { WalletProvider } from '@/lib/wallet-context';
import { VideoProvider, useVideo } from '@/lib/video-context';
import type { UiLang } from '@/i18n';
import { verifyAdminPassword, clearAdminPassword } from '@/lib/admin-api';

type Route = 'home' | 'tutor-payout' | 'video-call' | 'admin';

function getRouteFromHash(): Route {
  const hash = window.location.hash.replace(/^#\/?/, '');
  if (hash === 'tutor/payout') return 'tutor-payout';
  if (hash === 'video-call') return 'video-call';
  if (hash === 'admin' || hash.startsWith('admin/')) return 'admin';
  return 'home';
}

function getAdminPageFromHash(): AdminPage {
  const hash = window.location.hash.replace(/^#\/?/, '');
  if (hash === 'admin/tutors') return 'tutors';
  if (hash === 'admin/students') return 'students';
  if (hash === 'admin/payments') return 'payments';
  return 'dashboard';
}

export default function App() {
  const [selectedLang, setSelectedLang] = useState('en');
  const [uiLang, setUiLang] = useState<UiLang>('KR');
  const [route, setRoute] = useState<Route>(getRouteFromHash());
  const [buyModalOpen, setBuyModalOpen] = useState(false);
  const [applyOpen, setApplyOpen] = useState(false);
  const [adminMode, setAdminMode] = useState(false);
  const [adminPage, setAdminPage] = useState<AdminPage>(getAdminPageFromHash());
  const [gateOpen, setGateOpen] = useState(false);

  useEffect(() => {
    const onHashChange = () => {
      const newRoute = getRouteFromHash();
      setRoute(newRoute);
      if (newRoute === 'admin') {
        setAdminPage(getAdminPageFromHash());
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);



  const navigateToPayout = () => {
    window.location.hash = '#/tutor/payout';
  };

  const navigateToVideoCall = () => {
    window.location.hash = '#/video-call';
  };

  const navigateToHome = () => {
    window.location.hash = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToAdmin = (page: AdminPage) => {
    const hash = page === 'dashboard' ? '#/admin' : `#/admin/${page}`;
    window.location.hash = hash;
  };

  const handleAdminToggle = () => {
    if (!adminMode) {
      setGateOpen(true);
    } else {
      clearAdminPassword();
      setAdminMode(false);
    }
  };

  const handleGateSubmit = async (password: string): Promise<boolean> => {
    const ok = await verifyAdminPassword(password);
    if (ok) {
      setAdminMode(true);
      setGateOpen(false);
      return true;
    }
    return false;
  };

  const navigateBackToSite = () => {
    clearAdminPassword();
    setAdminMode(false);
    window.location.hash = '';
  };

  // Admin route
  if (route === 'admin') {
    if (!adminMode) return null;

    return (
      <AdminLayout
        uiLang={uiLang}
        activePage={adminPage}
        onNavigate={navigateToAdmin}
        adminMode={adminMode}
        onToggleAdmin={handleAdminToggle}
        onBackToSite={navigateBackToSite}
      >
        {adminPage === 'dashboard' && <AdminDashboard uiLang={uiLang} />}
        {adminPage === 'tutors' && <AdminTutors uiLang={uiLang} />}
        {adminPage === 'students' && <AdminStudents uiLang={uiLang} />}
        {adminPage === 'payments' && <AdminPayments uiLang={uiLang} />}
      </AdminLayout>
    );
  }

  return (
    <WalletProvider>
      <VideoProvider>
        <div className="min-h-screen bg-white">
          <Navbar
            selectedLang={selectedLang}
            onSelectLang={setSelectedLang}
            uiLang={uiLang}
            onUiLangChange={setUiLang}
            onBuyPoints={() => setBuyModalOpen(true)}
            onNavigatePayout={navigateToPayout}
            adminMode={adminMode}
            onToggleAdmin={handleAdminToggle}
            onNavigateAdmin={() => navigateToAdmin('dashboard')}
          />

          {route === 'tutor-payout' ? (
            <TutorPayout uiLang={uiLang} onBack={navigateToHome} />
          ) : route === 'video-call' ? (
            <VideoCallPage uiLang={uiLang} onBack={navigateToHome} />
          ) : (
            <main>
              <Hero selectedLang={selectedLang} onSelectLang={setSelectedLang} uiLang={uiLang} />
              <PopularTutors uiLang={uiLang} onJoinLesson={navigateToVideoCall} />
              <Features uiLang={uiLang} />
              <HowItWorks uiLang={uiLang} />
              <Testimonials uiLang={uiLang} />
              <CtaBanner uiLang={uiLang} onApply={() => setApplyOpen(true)} />
              <Faq uiLang={uiLang} />
            </main>
          )}

          {applyOpen && (
            <TutorApply uiLang={uiLang} onClose={() => setApplyOpen(false)} />
          )}

          <Footer uiLang={uiLang} />

          <BuyPointsModal open={buyModalOpen} onClose={() => setBuyModalOpen(false)} uiLang={uiLang} />

          {gateOpen && (
            <AdminGate
              uiLang={uiLang}
              onSubmit={handleGateSubmit}
              onClose={() => setGateOpen(false)}
            />
          )}
        </div>
      </VideoProvider>
    </WalletProvider>
  );
}

function VideoCallPage({ uiLang, onBack }: { uiLang: UiLang; onBack: () => void }) {
  const { joinRoom, status } = useVideo();

  useEffect(() => {
    if (status === 'idle') {
      joinRoom(null, 'Student');
    }
  }, [joinRoom, status]);

  return (
    <div className="container-page mx-auto max-w-4xl py-8">
      <div className="mb-4 flex items-center gap-3">
        <button
          onClick={onBack}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-ink-200 bg-white text-ink-600 transition-colors hover:bg-ink-100"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-display text-2xl font-extrabold text-ink-900">
          {uiLang === 'KR' ? '화상 수업' : 'Video Lesson'}
        </h1>
      </div>
      <VideoCall uiLang={uiLang} onLeave={onBack} />
    </div>
  );
}
