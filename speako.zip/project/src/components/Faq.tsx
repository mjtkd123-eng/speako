import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FAQS } from '@/data';
import { t, type UiLang } from '@/i18n';

type Props = { uiLang: UiLang };

export default function Faq({ uiLang }: Props) {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="py-16 lg:py-24">
      <div className="container-page">
        <div className="mx-auto max-w-2xl text-center">
          <span className="chip mb-3 bg-brand-50 text-brand-700">{t('faq', 'chip', uiLang)}</span>
          <h2 className="font-display text-3xl font-extrabold tracking-tight text-ink-900 sm:text-4xl">
            {t('faq', 'heading', uiLang)}
          </h2>
          <p className="mt-3 text-ink-600">
            {t('faq', 'sub', uiLang)}
          </p>
        </div>

        <div className="mx-auto mt-10 max-w-3xl space-y-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={i}
                className={`overflow-hidden rounded-2xl border bg-white transition-all duration-300 ${
                  isOpen ? 'border-primary-200 shadow-soft' : 'border-ink-100'
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                >
                  <span className="font-semibold text-ink-900">{item.q[uiLang]}</span>
                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-ink-400 transition-transform duration-300 ${
                      isOpen ? 'rotate-180 text-primary-500' : ''
                    }`}
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ${
                    isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 leading-relaxed text-ink-600">{item.a[uiLang]}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
