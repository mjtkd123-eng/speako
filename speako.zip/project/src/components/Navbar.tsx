import { useEffect, useRef, useState, useMemo } from 'react';
import {
  Globe,
  ChevronDown,
  Menu,
  X,
  Search,
  User,
  GraduationCap,
  Users,
  HelpCircle,
  Languages,
  CalendarClock,
  Wallet,
  ArrowRight,
  Shield,
  ShieldOff,
  LayoutDashboard,
} from 'lucide-react';
import { LANGUAGES, type Language } from '@/data';
import { t, type UiLang } from '@/i18n';
import WalletBadge from '@/components/WalletBadge';

type Props = {
  selectedLang: string;
  onSelectLang: (code: string) => void;
  uiLang: UiLang;
  onUiLangChange: (lang: UiLang) => void;
  onBuyPoints: () => void;
  onNavigatePayout: () => void;
  adminMode: boolean;
  onToggleAdmin: () => void;
  onNavigateAdmin: () => void;
};

const POPULAR_CODES = [
  'en',
  'en-gb',
  'es',
  'fr',
  'it',
  'ko',
  'de',
  'ja',
  'zh',
  'pt',
];

export default function Navbar({
  selectedLang,
  onSelectLang,
  uiLang,
  onUiLangChange,
  onBuyPoints,
  onNavigatePayout,
  adminMode,
  onToggleAdmin,
  onNavigateAdmin,
}: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  useEffect(() => {
    if (drawerOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [drawerOpen]);

  const current = LANGUAGES.find((l) => l.code === selectedLang) ?? LANGUAGES[0];

  const { popularLangs, otherLangs } = useMemo(() => {
    const popular: Language[] = [];
    const popularSet = new Set<string>();
    for (const code of POPULAR_CODES) {
      const found = LANGUAGES.find((l) => l.code === code);
      if (found) {
        popular.push(found);
        popularSet.add(code);
      }
    }
    const other = LANGUAGES.filter((l) => !popularSet.has(l.code)).sort((a, b) =>
      a.name.EN.localeCompare(b.name.EN),
    );
    return { popularLangs: popular, otherLangs: other };
  }, []);

  const renderLangButton = (l: Language) => (
    <button
      key={l.code}
      onClick={() => {
        onSelectLang(l.code);
        setLangOpen(false);
      }}
      className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-sm transition-colors ${
        l.code === selectedLang
          ? 'bg-primary-50 font-semibold text-primary-700'
          : 'text-ink-700 hover:bg-ink-50'
      }`}
    >
      <span className="text-base leading-none">{l.flag}</span>
      <span>{l.name[uiLang]}</span>
    </button>
  );

  const LangDropdown = (
    <div className="absolute left-0 top-full mt-2 w-60 origin-top animate-fade-up rounded-2xl border border-ink-100 bg-white p-2 shadow-lift">
      <div className="max-h-96 overflow-y-auto">
        <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-ink-400">
          {t('nav', 'popularLangs', uiLang)}
        </p>
        {popularLangs.map(renderLangButton)}
        <div className="my-2 border-t border-ink-100" />
        <p className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-ink-400">
          {t('nav', 'otherLangs', uiLang)}
        </p>
        {otherLangs.map(renderLangButton)}
      </div>
    </div>
  );

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'border-b border-ink-100 bg-white/85 backdrop-blur-lg shadow-soft'
            : 'border-b border-transparent bg-transparent'
        }`}
      >
        <div className="container-page flex h-16 items-center justify-between gap-3 lg:h-[72px]">
          {/* Logo */}
          <a href="#" className="flex shrink-0 items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-brand-500 text-white shadow-soft">
              <Globe className="h-5 w-5" strokeWidth={2.2} />
            </span>
            <span className="font-display text-xl font-extrabold tracking-tight text-ink-900">
              Speako
            </span>
          </a>

          {/* Desktop nav links */}
          <nav className="hidden items-center gap-1 lg:flex">
            <a
              href="#tutors"
              className="rounded-full px-4 py-2 text-sm font-medium text-ink-600 transition-colors hover:bg-ink-100 hover:text-ink-900"
            >
              {t('nav', 'findTutor', uiLang)}
            </a>
            <a
              href="#become-tutor"
              className="rounded-full px-4 py-2 text-sm font-medium text-ink-600 transition-colors hover:bg-ink-100 hover:text-ink-900"
            >
              {t('nav', 'becomeTutor', uiLang)}
            </a>
          </nav>

          {/* Desktop right cluster: [ 학습 언어 ] → [ 로그인/회원가입 ] → [ KR | EN ] */}
          <div className="hidden items-center gap-2 lg:flex">
            {/* Admin toggle — dev mode only */}
            {import.meta.env.DEV && (
              <>
                <button
                  onClick={onToggleAdmin}
                  title={adminMode ? 'Admin Mode ON' : 'Admin Mode OFF'}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-2 text-xs font-bold transition-all ${
                    adminMode
                      ? 'bg-ink-900 text-white'
                      : 'border border-ink-200 text-ink-400 hover:bg-ink-100 hover:text-ink-700'
                  }`}
                >
                  {adminMode ? <Shield className="h-4 w-4" /> : <ShieldOff className="h-4 w-4" />}
                  <span className="hidden xl:inline">ADMIN</span>
                </button>
                {adminMode && (
                  <button
                    onClick={onNavigateAdmin}
                    className="flex items-center gap-1.5 rounded-full bg-primary-600 px-3.5 py-2 text-xs font-bold text-white transition-all hover:bg-primary-700"
                  >
                    <LayoutDashboard className="h-4 w-4" />
                    <span className="hidden xl:inline">Dashboard</span>
                  </button>
                )}
              </>
            )}

            <WalletBadge uiLang={uiLang} onClick={onBuyPoints} />

            {/* Learn-language capsule dropdown */}
            <div ref={langRef} className="relative">
              <button
                onClick={() => setLangOpen((v) => !v)}
                className="flex items-center gap-2 rounded-full border border-ink-200 bg-white/80 px-3.5 py-2 text-sm font-medium text-ink-700 shadow-sm transition-all hover:border-primary-300 hover:bg-primary-50"
              >
                <span className="text-base leading-none">{current.flag}</span>
                <span className="whitespace-nowrap">
                  [ {t('nav', 'learnLangPrefix', uiLang)} {current.name[uiLang]}{' '}
                  <ChevronDown
                    className={`inline h-3.5 w-3.5 text-ink-400 transition-transform ${langOpen ? 'rotate-180' : ''}`}
                  />
                  ]
                </span>
              </button>
              {langOpen && LangDropdown}
            </div>

            {/* Login / Signup */}
            <button className="btn-ghost">{t('nav', 'login', uiLang)}</button>
            <button className="btn-primary">{t('nav', 'signup', uiLang)}</button>

            {/* KR | EN toggle */}
            <div className="flex items-center gap-1.5 rounded-full border border-ink-200 bg-white/80 px-3.5 py-2 text-sm font-medium text-ink-700 shadow-sm transition-all hover:border-primary-300 hover:bg-primary-50">
              <button
                onClick={() => onUiLangChange('KR')}
                className={`rounded-full px-2 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'KR' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
                aria-label="한국어"
              >
                KR
              </button>
              <span className="text-ink-300">|</span>
              <button
                onClick={() => onUiLangChange('EN')}
                className={`rounded-full px-2 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'EN' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
                aria-label="English"
              >
                EN
              </button>
            </div>
          </div>

          {/* Mobile/tablet right cluster */}
          <div className="flex items-center gap-1.5 lg:hidden">
            {/* Learn-language capsule (mobile) — compact: flag + chevron only */}
            <div ref={langRef} className="relative shrink-0">
              <button
                onClick={() => setLangOpen((v) => !v)}
                className="flex items-center gap-1 rounded-full border border-ink-200 bg-white/80 px-2.5 py-2 text-xs font-medium text-ink-700 shadow-sm transition-all hover:border-primary-300 hover:bg-primary-50"
                aria-label={t('nav', 'learnLangPrefix', uiLang)}
              >
                <span className="text-base leading-none">{current.flag}</span>
                <ChevronDown
                  className={`h-3 w-3 text-ink-400 transition-transform ${langOpen ? 'rotate-180' : ''}`}
                />
              </button>
              {langOpen && LangDropdown}
            </div>

            {/* KR | EN toggle (mobile) */}
            <div className="flex shrink-0 items-center gap-1 rounded-full border border-ink-200 bg-white/80 px-2.5 py-2 text-xs font-medium text-ink-700 shadow-sm transition-all hover:border-primary-300 hover:bg-primary-50">
              <button
                onClick={() => onUiLangChange('KR')}
                className={`rounded-full px-1.5 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'KR' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
                aria-label="한국어"
              >
                KR
              </button>
              <span className="text-ink-300">|</span>
              <button
                onClick={() => onUiLangChange('EN')}
                className={`rounded-full px-1.5 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'EN' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
                aria-label="English"
              >
                EN
              </button>
            </div>

            {/* Hamburger */}
            <button
              onClick={() => setDrawerOpen(true)}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-ink-700 transition-colors hover:bg-ink-100"
              aria-label={t('nav', 'openMenu', uiLang)}
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Slide-out drawer */}
      {drawerOpen && (
        <MobileDrawer
          onClose={() => setDrawerOpen(false)}
          uiLang={uiLang}
          onUiLangChange={onUiLangChange}
          onNavigatePayout={onNavigatePayout}
          adminMode={adminMode}
          onToggleAdmin={onToggleAdmin}
          onNavigateAdmin={() => {
            setDrawerOpen(false);
            onNavigateAdmin();
          }}
        />
      )}
    </>
  );
}

/* ---------- Drawer ---------- */

type DrawerProps = {
  onClose: () => void;
  uiLang: UiLang;
  onUiLangChange: (lang: UiLang) => void;
  onNavigatePayout: () => void;
  adminMode: boolean;
  onToggleAdmin: () => void;
  onNavigateAdmin: () => void;
};

function MobileDrawer({
  onClose,
  uiLang,
  onUiLangChange,
  onNavigatePayout,
  adminMode,
  onToggleAdmin,
  onNavigateAdmin,
}: DrawerProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[60] lg:hidden">
      {/* Overlay */}
      <div
        className="absolute inset-0 animate-overlay-in bg-ink-900/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Panel */}
      <div
        ref={panelRef}
        className="absolute right-0 top-0 flex h-full w-[88%] max-w-sm animate-slide-in-right flex-col bg-white shadow-2xl"
        role="dialog"
        aria-modal="true"
      >
        {/* Drawer header */}
        <div className="flex items-center justify-between border-b border-ink-100 px-5 py-4">
          <a href="#" className="flex items-center gap-2" onClick={onClose}>
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary-500 to-brand-500 text-white">
              <Globe className="h-4.5 w-4.5" strokeWidth={2.2} />
            </span>
            <span className="font-display text-lg font-extrabold tracking-tight text-ink-900">
              Speako
            </span>
          </a>
          <button
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl text-ink-600 transition-colors hover:bg-ink-100"
            aria-label={t('nav', 'closeMenu', uiLang)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto px-5 py-5">
          {/* ===== Top: Auth ===== */}
          <div className="animate-drawer-item grid grid-cols-2 gap-2.5">
            <button className="btn-outline flex-1">
              <User className="h-4 w-4" />
              {t('nav', 'login', uiLang)}
            </button>
            <button className="btn-primary flex-1">{t('nav', 'signup', uiLang)}</button>
          </div>

          {/* ===== KR | EN toggle in drawer ===== */}
          <div className="mt-4 flex items-center justify-center">
            <div className="flex items-center gap-1.5 rounded-full border border-ink-200 bg-white px-4 py-2 text-sm font-medium text-ink-700 shadow-sm transition-all hover:border-primary-300 hover:bg-primary-50">
              <button
                onClick={() => onUiLangChange('KR')}
                className={`rounded-full px-2.5 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'KR' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
              >
                KR
              </button>
              <span className="text-ink-300">|</span>
              <button
                onClick={() => onUiLangChange('EN')}
                className={`rounded-full px-2.5 py-0.5 text-xs font-bold transition-colors ${
                  uiLang === 'EN' ? 'bg-primary-600 text-white' : 'text-ink-500 hover:text-ink-800'
                }`}
              >
                EN
              </button>
            </div>
          </div>

          {/* ===== Menu links ===== */}
          <div className="mt-6 space-y-2">
            <DrawerLink
              href="#tutors"
              onClick={onClose}
              icon={Search}
              title={t('drawer', 'findTutorTitle', uiLang)}
              subtitle={t('drawer', 'findTutorSub', uiLang)}
              filters={[
                { icon: Languages, label: t('drawer', 'filterLang', uiLang) },
                { icon: Wallet, label: t('drawer', 'filterPrice', uiLang) },
                { icon: CalendarClock, label: t('drawer', 'filterTime', uiLang) },
              ]}
            />

            <DrawerLink
              href="#"
              onClick={onClose}
              icon={Users}
              title={t('drawer', 'groupClassTitle', uiLang)}
              subtitle={t('drawer', 'groupClassSub', uiLang)}
              badge="NEW"
            />

            <DrawerLink
              href="#"
              onClick={onClose}
              icon={HelpCircle}
              title={t('drawer', 'qaTitle', uiLang)}
              subtitle={t('drawer', 'qaSub', uiLang)}
            />
          </div>

          {/* ===== Admin entry (mobile drawer) — dev mode only ===== */}
          {import.meta.env.DEV && (
            <div className="mt-4">
              <button
                onClick={onToggleAdmin}
                className={`flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${
                  adminMode
                    ? 'bg-ink-900 text-white hover:bg-ink-800'
                    : 'border border-ink-200 text-ink-500 hover:bg-ink-100'
                }`}
              >
                {adminMode ? <Shield className="h-4 w-4" /> : <ShieldOff className="h-4 w-4" />}
                {adminMode ? 'Admin Mode ON' : 'Admin Mode'}
              </button>
              {adminMode && (
                <button
                  onClick={onNavigateAdmin}
                  className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-primary-600 px-4 py-2.5 text-sm font-bold text-white transition-all hover:bg-primary-700"
                >
                  <LayoutDashboard className="h-4 w-4" />
                  Admin Dashboard
                </button>
              )}
            </div>
          )}

          {/* ===== Highlight: Become a tutor ===== */}
          <div className="mt-6">
            <button
              onClick={() => {
                onClose();
                onNavigatePayout();
              }}
              className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl border border-ink-200 bg-white px-4 py-2.5 text-sm font-semibold text-ink-700 transition-all hover:border-primary-300 hover:bg-primary-50 hover:text-primary-700"
            >
              <Wallet className="h-4 w-4" />
              {t('wallet', 'payoutPage', uiLang)}
            </button>
            <a
              href="#become-tutor"
              onClick={onClose}
              className="group relative block overflow-hidden rounded-2xl bg-gradient-to-br from-primary-600 to-brand-600 p-5 text-white shadow-lift transition-transform hover:scale-[1.02] active:scale-[0.99]"
            >
              <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-white/10 blur-xl" />
              <div className="relative flex items-start gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/15 ring-1 ring-white/20">
                  <GraduationCap className="h-6 w-6" />
                </span>
                <div className="flex-1">
                  <p className="text-xs font-semibold uppercase tracking-wide text-primary-50">
                    {t('drawer', 'tutorRecruit', uiLang)}
                  </p>
                  <h3 className="mt-0.5 font-display text-lg font-bold leading-tight">
                    {t('drawer', 'tutorCtaTitle', uiLang)}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-primary-50">
                    {t('drawer', 'tutorCtaDesc', uiLang)}
                  </p>
                  <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-sm font-semibold text-primary-700 transition-transform group-hover:translate-x-0.5">
                    {t('drawer', 'tutorCtaBtn', uiLang)}
                    <ArrowRight className="h-4 w-4" />
                  </span>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Drawer link ---------- */

type DrawerLinkProps = {
  href: string;
  onClick: () => void;
  icon: typeof Search;
  title: string;
  subtitle?: string;
  badge?: string;
  filters?: { icon: typeof Languages; label: string }[];
};

function DrawerLink({ href, onClick, icon: Icon, title, subtitle, badge, filters }: DrawerLinkProps) {
  return (
    <a
      href={href}
      onClick={onClick}
      className="group flex items-center gap-3.5 rounded-xl border border-ink-100 bg-white px-3.5 py-3 transition-all hover:border-primary-200 hover:bg-primary-50/40"
    >
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-ink-50 text-ink-600 transition-colors group-hover:bg-primary-100 group-hover:text-primary-700">
        <Icon className="h-5 w-5" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="font-semibold text-ink-900">{title}</p>
          {badge && (
            <span className="rounded-full bg-accent-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-accent-700">
              {badge}
            </span>
          )}
        </div>
        {subtitle && <p className="mt-0.5 truncate text-xs text-ink-500">{subtitle}</p>}
        {filters && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {filters.map((f) => {
              const FIcon = f.icon;
              return (
                <span
                  key={f.label}
                  className="inline-flex items-center gap-1 rounded-full bg-ink-100 px-2 py-0.5 text-[11px] font-medium text-ink-500"
                >
                  <FIcon className="h-3 w-3" />
                  {f.label}
                </span>
              );
            })}
          </div>
        )}
      </div>
      <ArrowRight className="h-4 w-4 shrink-0 text-ink-300 transition-all group-hover:translate-x-0.5 group-hover:text-primary-500" />
    </a>
  );
}
